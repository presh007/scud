# COMPRESS APP --------------------------------------------------------------------------------------------------
COMPRESS_MIMETYPES = ['text/html', 'text/css', 'text/xml', 'application/json', 'application/javascript']
COMPRESS_LEVEL = 6
COMPRESS_MIN_SIZE = 500
# ---------------------------------------------------------------------------------------------------------------
# LOCAL CONFIGS--------------------------------------------------------------------------------------------------
DATABASE = "./database.db"
url = 'https://github.com/UndeadSec/SocialFish'
red = 'https://github.com/UndeadSec/SocialFish'
sta = 'x'
APP_SECRET_KEY = '<CHANGE ME SF>'
# ---------------------------------------------------------------------------------------------------------------